import { Routes, Route, useLocation } from "react-router-dom";
import RoleSelect from "./pages/RoleSelect";
import DriverLogin from "./pages/driver/Login";
import DriverRegister from "./pages/driver/Register";
import PassengerLogin from "./pages/passenger/Login";
import PassengerRegister from "./pages/passenger/Register";
import Navbar from "./components/Navbar";

export default function App() {
  const location = useLocation();
  const hideNavbarRoutes = ["/"]; // hide navbar only on landing page

  return (
    <div className="min-h-screen flex flex-col">
      {!hideNavbarRoutes.includes(location.pathname) && <Navbar />}
      <div className="flex-1">
        <Routes>
          {/* Landing page */}
          <Route path="/" element={<RoleSelect />} />

          {/* Driver auth */}
          <Route path="/driver/login" element={<DriverLogin />} />
          <Route path="/driver/register" element={<DriverRegister />} />

          {/* Passenger auth */}
          <Route path="/passenger/login" element={<PassengerLogin />} />
          <Route path="/passenger/register" element={<PassengerRegister />} />

          {/* Future routes for dashboards, rides, etc. */}
        </Routes>
      </div>
    </div>
  );
}
