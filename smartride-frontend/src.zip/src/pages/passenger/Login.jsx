import { Link } from "react-router-dom";

export default function PassengerLogin() {
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-5rem)] px-4">
      <div className="w-full max-w-md bg-white shadow-lg rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-brandGreen mb-6">Passenger Login</h2>

        <form className="space-y-4">
          <input
            type="text"
            placeholder="Email or Phone Number"
            required
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-brandGreen outline-none"
          />
          <input
            type="password"
            placeholder="Password"
            required
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-brandGreen outline-none"
          />

          <button
            type="submit"
            className="w-full bg-brandGreen text-white py-2 rounded-lg font-medium hover:bg-green-700 transition"
          >
            Login
          </button>
        </form>

        <p className="mt-6 text-center text-sm">
          Don’t have an account?{" "}
          <Link to="/passenger/register" className="text-brandGreen font-medium hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
