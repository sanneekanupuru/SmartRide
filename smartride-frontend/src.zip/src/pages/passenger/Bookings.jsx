import { useEffect, useState } from "react";
import api from "../../services/api";

export default function PassengerBookings(){
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState("");

  useEffect(()=>{
    (async ()=>{
      try{
        const { data } = await api.get("/bookings/mine");
        setRows(Array.isArray(data) ? data : []);
      }catch(e){
        setErr(e?.response?.data?.message || "Failed to load bookings");
      }
    })();
  },[]);

  return (
    <div className="container py-5">
      <h2 className="mb-3">My Bookings</h2>
      {err && <div className="alert alert-danger">{err}</div>}
      <div className="table-responsive">
        <table className="table table-striped">
          <thead><tr><th>Ride</th><th>Date</th><th>Time</th><th>Seats</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map(b=>(
              <tr key={b.id}>
                <td>{b.source} → {b.destination}</td>
                <td>{b.departure_date}</td>
                <td>{b.departure_time}</td>
                <td>{b.seats_booked}</td>
                <td>{b.booking_status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
