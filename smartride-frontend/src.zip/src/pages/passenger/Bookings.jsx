import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../services/api";

export default function PassengerBookings() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const { data } = await api.get("/bookings/mine");
        setBookings(Array.isArray(data) ? data : [data]);
      } catch (e) {
        setError(e?.response?.data?.error || "Failed to fetch bookings");
      }
    };
    fetchBookings();
  }, []);

  const formatDate = (b) =>
    b.departureDatetime
      ? new Date(b.departureDatetime).toLocaleDateString()
      : "";

  const formatTime = (b) =>
    b.departureDatetime
      ? new Date(b.departureDatetime).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        })
      : "";

  // Booking Status Badge
  const getBookingBadge = (status) => {
    switch (status) {
      case "CONFIRMED":
        return (
          <span className="badge bg-success me-2">
            <i className="bi bi-check-circle-fill me-1"></i> Confirmed
          </span>
        );
      case "PENDING":
        return (
          <span className="badge bg-warning text-dark me-2">
            <i className="bi bi-hourglass-split me-1"></i> Pending
          </span>
        );
      case "CANCELLED":
        return (
          <span className="badge bg-danger me-2">
            <i className="bi bi-x-circle-fill me-1"></i> Cancelled
          </span>
        );
      default:
        return (
          <span className="badge bg-secondary me-2">
            <i className="bi bi-question-circle me-1"></i> {status}
          </span>
        );
    }
  };

  // Payment Status Badge
  const getPaymentBadge = (status) => {
    switch (status) {
      case "SUCCESS":
        return (
          <span className="badge bg-success">
            <i className="bi bi-cash-stack me-1"></i> Paid
          </span>
        );
      case "PENDING":
      default:
        return (
          <span className="badge bg-danger">
            <i className="bi bi-credit-card me-1"></i> Pending
          </span>
        );
    }
  };

  const handleRedirectToPayment = (booking) => {
    navigate("/payments", {
      state: {
        bookingId: booking.bookingId,
        amount: booking.totalPrice,
        rideId: booking.rideId,
      },
    });
  };

  const handleCancel = async (bookingId) => {
    try {
      await api.post(`/bookings/${bookingId}/cancel`);
      alert("Booking Cancelled!");
      window.location.reload();
    } catch (err) {
      alert("Cancellation failed!");
    }
  };

  return (
    <div className="container py-5">
      <h2 className="mb-4">My Bookings</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      {bookings.length === 0 ? (
        <div className="alert alert-info">No bookings found.</div>
      ) : (
        <div className="row">
          {bookings.map((b) => (
            <div className="col-12 mb-4" key={b.bookingId}>
              <div className="card shadow-sm h-100 border-0 rounded-3">
                <div className="card-body">
                  {/* Route + Price */}
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h5 className="card-title mb-0">
                      {b.source} → {b.destination}
                    </h5>
                  </div>

                  {/* Fare details */}
                  <div className="mb-2">
                    <p className="mb-1 text-muted">
                      Seat Price: <strong>₹{b.price}</strong>
                    </p>
                    <p className="mb-1 text-muted">
                      Seats Booked: <strong>{b.seatsBooked}</strong>
                    </p>
                    <p className="mb-0 text-dark fw-bold">
                      Total Fare: ₹{b.totalPrice}
                    </p>
                  </div>

                  {/* Driver */}
                  <p className="text-muted mb-1">
                    <i className="bi bi-person-fill"></i> Driver:{" "}
                    <strong>{b.driverName}</strong>
                  </p>

                  {/* Date + Time */}
                  <p className="text-muted mb-1">
                    <i className="bi bi-calendar-event"></i> {formatDate(b)} at{" "}
                    {formatTime(b)}
                  </p>

                  {/* Seats */}
                  <p className="text-muted mb-1">
                    <i className="bi bi-people-fill"></i> Seats booked:{" "}
                    {b.seatsBooked}
                  </p>

                  {/* Statuses with labels */}
                  <div className="mt-3">
                    <div className="mb-1">
                      <small className="fw-bold text-secondary me-1">
                        Booking:
                      </small>
                      {getBookingBadge(b.bookingStatus)}
                    </div>
                    <div>
                      <small className="fw-bold text-secondary me-1">
                        Payment:
                      </small>
                      {getPaymentBadge(b.paymentStatus)}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="mt-3 d-flex justify-content-end gap-2">
                    {b.paymentStatus === "PENDING" && (
                      <button
                        className="btn btn-sm btn-success"
                        onClick={() => handleRedirectToPayment(b)}
                      >
                        💳 Pay Now
                      </button>
                    )}
                    {b.bookingStatus === "PENDING" && (
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleCancel(b.bookingId)}
                      >
                        ❌ Cancel
                      </button>
                    )}
                  </div>
                </div>

                {/* Footer IDs */}
                <div className="card-footer text-muted small text-end">
                  Booking ID: {b.bookingId} | Ride ID: {b.rideId}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
