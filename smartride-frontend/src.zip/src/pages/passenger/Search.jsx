import { useState } from "react";
import api from "../../services/api";

export default function PassengerSearch(){
  const [q,setQ] = useState({ source:"", destination:"", departure_date:"" });
  const [results, setResults] = useState([]);
  const [err,setErr] = useState("");
  const [seats, setSeats] = useState(1);
  const [message, setMessage] = useState("");

  const onChange = (e)=> setQ({ ...q, [e.target.name]: e.target.value });

  const search = async (e)=>{
    e.preventDefault();
    setErr(""); setMessage("");
    try{
      const { data } = await api.get("/rides", { params: { source: q.source, destination: q.destination, date: q.departure_date } });
      setResults(Array.isArray(data) ? data : []);
    }catch(e){
      setErr(e?.response?.data?.message || "Search failed");
    }
  };

  const book = async (rideId)=>{
    setErr(""); setMessage("");
    try{
      await api.post("/bookings", { ride_id: rideId, seats_booked: Number(seats) });
      setMessage("Booking confirmed");
    }catch(e){
      setErr(e?.response?.data?.message || "Booking failed");
    }
  };

  return (
    <div className="container py-5">
      <h2 className="mb-3">Search Rides</h2>
      {err && <div className="alert alert-danger">{err}</div>}
      {message && <div className="alert alert-success">{message}</div>}
      <form className="card p-3 shadow-sm mb-4" onSubmit={search}>
        <div className="row g-3 align-items-end">
          <div className="col-md-3"><label className="form-label">From</label><input className="form-control" name="source" value={q.source} onChange={onChange} required /></div>
          <div className="col-md-3"><label className="form-label">To</label><input className="form-control" name="destination" value={q.destination} onChange={onChange} required /></div>
          <div className="col-md-3"><label className="form-label">Date</label><input type="date" className="form-control" name="departure_date" value={q.departure_date} onChange={onChange} required /></div>
          <div className="col-md-3"><button className="btn btn-primary w-100">Search</button></div>
        </div>
      </form>

      <div className="table-responsive">
        <table className="table table-bordered align-middle">
          <thead><tr><th>From</th><th>To</th><th>Date</th><th>Time</th><th>Seats Avail</th><th>Price</th><th>Seats</th><th></th></tr></thead>
          <tbody>
            {results.map(r=>(
              <tr key={r.id}>
                <td>{r.source}</td>
                <td>{r.destination}</td>
                <td>{r.departure_date}</td>
                <td>{r.departure_time}</td>
                <td>{r.seats_available}</td>
                <td>{r.price}</td>
                <td style={{width:120}}><input type="number" min="1" max={r.seats_available} className="form-control" value={seats} onChange={e=>setSeats(e.target.value)} /></td>
                <td><button className="btn btn-success" disabled={seats<1} onClick={()=>book(r.id)}>Book</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
