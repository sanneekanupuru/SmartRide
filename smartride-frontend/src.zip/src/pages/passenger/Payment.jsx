import React, { useEffect, useState } from "react";
import api from "../../services/api";
import { useParams, useNavigate } from "react-router-dom";

const PassengerPayment = () => {
  const { bookingId } = useParams();
  const navigate = useNavigate();

  const [fare, setFare] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState("CASH");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!bookingId) {
      setMessage("Booking ID missing.");
      setLoading(false);
      return;
    }

    const fetchFare = async () => {
      try {
        const res = await api.get(`/payments/estimate/${bookingId}`);
        setFare(res.data.totalFare);
      } catch (err) {
        console.error("Error fetching fare:", err);
        setMessage("Failed to fetch fare.");
      } finally {
        setLoading(false);
      }
    };

    fetchFare();
  }, [bookingId]);

  const handlePayment = async () => {
    try {
      const res = await api.post(
        `/payments/pay/${bookingId}?paymentMethodStr=${paymentMethod.toUpperCase()}`
      );
      setMessage(`✅ Payment successful! Amount: ₹${res.data.amount.toFixed(2)}`);
      setTimeout(() => navigate("/passenger/dashboard"), 2000);
    } catch (err) {
      console.error("Payment failed:", err);
      setMessage("❌ Payment failed. Try again.");
    }
  };

  if (loading)
    return <p className="text-center mt-6 text-gray-500">Loading payment details...</p>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4 text-center">
          Payment for Booking #{bookingId}
        </h2>

        {fare !== null ? (
          <div className="bg-yellow-100 text-yellow-800 rounded-lg p-4 mb-6 text-center">
            <p className="text-lg font-semibold">
              💰 Total Fare: <span className="text-2xl font-bold">₹{fare.toFixed(2)}</span>
            </p>
          </div>
        ) : (
          <p className="text-red-500 text-center">{message}</p>
        )}

        <div className="mb-6">
          <label className="block text-sm font-medium mb-2 text-gray-700">
            Select Payment Method
          </label>
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          >
            <option value="CASH">Cash</option>
            <option value="CARD">Card</option>
            <option value="UPI">UPI</option>
          </select>
        </div>

        <button
          onClick={handlePayment}
          className="w-full bg-yellow-400 text-gray-900 font-bold py-3 rounded-lg shadow hover:bg-yellow-500 transition"
        >
          Pay Now
        </button>

        {message && (
          <p className="mt-6 text-center text-sm font-medium text-gray-700">{message}</p>
        )}
      </div>
    </div>
  );
};

export default PassengerPayment;
