// src/pages/admin/DisputesTable.jsx
import { useEffect, useState } from "react";
import api from "../../services/api";

export default function DisputesTable() {
  const [disputes, setDisputes] = useState([]);
  const [err, setErr] = useState("");

  const fetchDisputes = async () => {
    try {
      const { data } = await api.get("/admin/disputes");
      setDisputes(Array.isArray(data) ? data : data ? [data] : []);
    } catch (e) {
      console.error(e);
      setErr(e?.response?.data?.error || "Failed to fetch disputes");
    }
  };

  useEffect(() => { fetchDisputes(); }, []);

  return (
    <div className="container py-5">
      <h2 className="mb-4">Disputed Bookings</h2>
      {err && <div className="alert alert-danger">{err}</div>}
      {disputes.length === 0 ? (
        <div className="alert alert-info">No disputes found.</div>
      ) : (
        <div className="row">
          {disputes.map((d) => (
            <div className="col-12 mb-4" key={d.disputeId}>
              <div className="card shadow-sm h-100 border-0 rounded-3">
                <div className="card-body">
                  <p><strong>Booking ID:</strong> {d.bookingId} | <strong>Ride ID:</strong> {d.rideId}</p>
                  <p><strong>Passenger:</strong> {d.passengerName}</p>
                  <p><strong>Driver:</strong> {d.driverName}</p>
                  <p><strong>Reason:</strong> {d.reason}</p>
                  <p><strong>Status:</strong> {d.status}</p>
                  {d.adminNotes && <p><strong>Admin Notes:</strong> {d.adminNotes}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
