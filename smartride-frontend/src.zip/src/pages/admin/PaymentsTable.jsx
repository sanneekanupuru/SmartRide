import { useEffect, useState } from "react";
import api from "../../services/api";

export default function PaymentsTable() {
  const [payments, setPayments] = useState([]);
  const [err, setErr] = useState("");

  const fetchPayments = async () => {
    try {
      const { data } = await api.get("/admin/payments");
      setPayments(Array.isArray(data) ? data : data ? [data] : []);
      setErr("");
    } catch (e) {
      console.error(e);
      setErr(e?.response?.data || "Failed to fetch payments");
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  // Badge for status only
  const getPaymentBadge = (paymentStatus) => {
    const normalizedStatus = String(paymentStatus || "").toLowerCase();
    const isCompleted = normalizedStatus === "completed" || normalizedStatus === "paid";
    const badgeClass = isCompleted ? "bg-success" : "bg-warning";
    const text = isCompleted ? "Completed" : "Pending";
    return <span className={`badge ${badgeClass} text-white`}>{text}</span>;
  };

  const handleMarkPaid = async (paymentId) => {
    try {
      await api.patch(`/admin/payments/${paymentId}/status?status=COMPLETED`);
      alert("✅ Payment marked as completed!");
      fetchPayments(); // Refresh list
    } catch (e) {
      console.error(e);
      alert("❌ Failed to update payment status");
    }
  };

  return (
    <div className="container py-5">
      <h2 className="mb-4">All Payments</h2>

      {err && <div className="alert alert-danger">{err}</div>}

      {payments.length === 0 ? (
        <div className="alert alert-info">No payments found.</div>
      ) : (
        <div className="row">
          {payments.map((p) => (
            <div className="col-md-6 col-lg-4 mb-4" key={p.paymentId}>
              <div className="card shadow-sm border-0 rounded-3 h-100">
                <div className="card-body">
                  <h5 className="card-title mb-3">
                    Booking #{p.bookingId} {getPaymentBadge(p.paymentStatus)}
                  </h5>

                  <p className="mb-1"><strong>Passenger:</strong> {p.passengerName || "Unknown"}</p>
                  <p className="mb-1"><strong>Driver:</strong> {p.driverName || "Unknown"}</p>
                  <p className="mb-1"><strong>Amount:</strong> ₹{Number(p.amount)?.toFixed(2)}</p>
                  <p className="mb-2"><strong>Payment Method:</strong> {p.paymentMethod || "Unknown"}</p>

                  {/* Show "Mark as Paid" button only for pending CASH payments */}
                  {p.paymentMethod?.toUpperCase() === "CASH" &&
                    String(p.paymentStatus || "").toLowerCase() === "pending" && (
                      <button
                        className="btn btn-sm btn-success mt-2"
                        onClick={() => handleMarkPaid(p.paymentId)}
                      >
                        Mark as Paid
                      </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
