// src/pages/admin/StatsCards.jsx
export default function StatsCards({ stats }) {
  const cards = [
    { label: "Total Users", value: stats.totalUsers || 0 },
    { label: "Active Users", value: stats.activeUsers || 0 },
    { label: "Total Rides", value: stats.totalRides || 0 },
    { label: "Total Bookings", value: stats.totalBookings || 0 },
    { label: "Total Payments", value: stats.totalPayments || 0 },
    { label: "Total Earnings", value: stats.totalEarnings || 0 },
    { label: "Cancelled Bookings", value: stats.cancelledBookings || 0 },
    { label: "Disputed Bookings", value: stats.disputedBookings || 0 },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => (
        <div key={card.label} className="bg-purple-600 text-white p-4 rounded-lg shadow">
          <h3 className="text-sm font-medium">{card.label}</h3>
          <p className="text-2xl font-bold mt-2">{card.value}</p>
        </div>
      ))}
    </div>
  );
}
