// src/pages/admin/AdminDashboard.jsx
import { useState, useEffect } from "react";
import StatsCards from "./StatsCards";
import UsersTable from "./UsersTable";
import RidesTable from "./RidesTable";
import BookingsTable from "./BookingsTable";
import PaymentsTable from "./PaymentsTable";
import DisputesTable from "./DisputesTable";
import api from "../../services/api";

export default function AdminDashboard() {
  const [stats, setStats] = useState({});
  const [activeTab, setActiveTab] = useState("stats");

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data } = await api.get("/admin/stats");
      setStats(data);
    } catch (err) {
      console.error("Failed to fetch stats:", err);
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        {["stats", "users", "rides", "bookings", "payments", "disputes"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg font-semibold ${
              activeTab === tab ? "bg-purple-600 text-white" : "bg-white text-gray-700 shadow"
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Render active tab */}
      <div className="bg-white p-6 rounded-lg shadow">
        {activeTab === "stats" && <StatsCards stats={stats} />}
        {activeTab === "users" && <UsersTable />}
        {activeTab === "rides" && <RidesTable />}
        {activeTab === "bookings" && <BookingsTable />}
        {activeTab === "payments" && <PaymentsTable />}
        {activeTab === "disputes" && <DisputesTable />}
      </div>
    </div>
  );
}
