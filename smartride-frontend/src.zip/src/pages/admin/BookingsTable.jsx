// src/pages/admin/BookingsTable.jsx
import React, { useEffect, useState } from "react";
import api from "../../services/api";

export default function BookingsTable() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const { data } = await api.get("/admin/bookings");
        setBookings(Array.isArray(data) ? data : data ? [data] : []);
      } catch (e) {
        setError(e?.response?.data?.error || "Failed to fetch bookings");
      }
    };
    fetchBookings();
  }, []);

  const formatDateTime = (dtStr) =>
    dtStr
      ? new Date(dtStr).toLocaleDateString() +
        " at " +
        new Date(dtStr).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        })
      : "-";

  const getBookingBadge = (status) => {
    switch (status) {
      case "CONFIRMED":
        return <span className="badge bg-success me-2">Confirmed</span>;
      case "PENDING":
        return <span className="badge bg-warning text-dark me-2">Pending</span>;
      case "CANCELLED":
        return <span className="badge bg-danger me-2">Cancelled</span>;
      default:
        return <span className="badge bg-secondary me-2">{status}</span>;
    }
  };

  const getPaymentBadge = (status, method) => {
    if (status === "COMPLETED") {
      return <span className="badge bg-success">Paid {method && `(${method})`}</span>;
    }
    return <span className="badge bg-danger">Pending</span>;
  };

  return (
    <div className="container py-5">
      <h2 className="mb-4">All Bookings</h2>
      {error && <div className="alert alert-danger">{error}</div>}

      {bookings.length === 0 ? (
        <div className="alert alert-info">No bookings found.</div>
      ) : (
        <div className="row">
          {bookings.map((b) => (
            <div className="col-12 mb-4" key={b.bookingId}>
              <div className="card shadow-sm h-100 border-0 rounded-3">
                <div className="card-body">
                  {/* Route */}
                  <h5 className="card-title mb-2">
                    {b.source || "-"} → {b.destination || "-"}
                  </h5>

                  {/* Passenger */}
                  <p className="mb-1 text-muted">
                    Passenger: <strong>{b.passengerName || "-"}</strong>
                  </p>

                  {/* Driver */}
                  <p className="mb-1 text-muted">
                    Driver: <strong>{b.driverName || "-"}</strong>
                  </p>

                  {/* Seats & Fare */}
                  <p className="mb-1 text-muted">Seats Booked: {b.seatsBooked || 0}</p>
                  <p className="mb-2 text-dark fw-bold">
                    Total Fare: ₹{b.totalPrice?.toFixed(2) || 0}
                  </p>

                  {/* Date + Time */}
                  <p className="mb-2 text-muted">
                    Departure: {formatDateTime(b.departureDatetime)}
                  </p>

                  {/* Status */}
                  <div className="mb-2">
                    Booking: {getBookingBadge(b.bookingStatus)} | Payment:{" "}
                    {getPaymentBadge(b.paymentStatus, b.paymentMethod)}
                  </div>
                </div>

                {/* Footer */}
                <div className="card-footer text-muted small text-end">
                  Booking ID: {b.bookingId} | Ride ID: {b.rideId || "-"}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
