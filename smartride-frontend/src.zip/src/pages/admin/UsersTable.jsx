// src/pages/admin/UsersTable.jsx
import { useEffect, useState } from "react";
import api from "../../services/api";

export default function UsersTable() {
  const [users, setUsers] = useState([]);

  const fetchUsers = async () => {
    try {
      const { data } = await api.get("/admin/users");
      setUsers(data);
    } catch (err) {
      console.error("Failed to fetch users:", err);
    }
  };

  const blockUser = async (id) => {
    try {
      await api.put(`/admin/block-user/${id}`);
      fetchUsers();
    } catch (err) {
      console.error("Failed to block user:", err);
    }
  };

  const verifyDriver = async (id) => {
    try {
      await api.put(`/admin/verify-driver/${id}`);
      fetchUsers();
    } catch (err) {
      console.error("Failed to verify driver:", err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full table-auto border">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2 border">ID</th>
            <th className="px-4 py-2 border">Name</th>
            <th className="px-4 py-2 border">Email</th>
            <th className="px-4 py-2 border">Role</th>
            <th className="px-4 py-2 border">Status</th>
            <th className="px-4 py-2 border">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id} className="text-center">
              <td className="px-4 py-2 border">{u.id}</td>
              <td className="px-4 py-2 border">{u.name}</td>
              <td className="px-4 py-2 border">{u.email}</td>
              <td className="px-4 py-2 border">{u.role}</td>
              <td className="px-4 py-2 border">{u.isBlocked ? "Blocked" : "Active"}</td>
              <td className="px-4 py-2 border space-x-2">
                {!u.isBlocked && (
                  <button
                    className="bg-red-500 text-white px-2 py-1 rounded"
                    onClick={() => blockUser(u.id)}
                  >
                    Block
                  </button>
                )}
                {!u.verified && u.role === "DRIVER" && (
                  <button
                    className="bg-green-500 text-white px-2 py-1 rounded"
                    onClick={() => verifyDriver(u.id)}
                  >
                    Verify
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
