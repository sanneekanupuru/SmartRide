import { useState } from "react";
import api from "../../services/api";

export default function DriverPostRide(){
  const [form, setForm] = useState({ source:"", destination:"", departure_date:"", departure_time:"", seats_total:1, price:0 });
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  const onChange = (e)=> setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e)=>{
    e.preventDefault();
    setMsg(""); setErr("");
    try{
      await api.post("/rides", { 
        source: form.source, destination: form.destination,
        departure_date: form.departure_date, departure_time: form.departure_time,
        seats_total: Number(form.seats_total), price: Number(form.price)
      });
      setMsg("Ride posted successfully");
      setForm({ source:"", destination:"", departure_date:"", departure_time:"", seats_total:1, price:0 });
    }catch(error){
      setErr(error?.response?.data?.message || "Failed to post ride");
    }
  };

  return (
    <div className="container py-5" style={{maxWidth:720}}>
      <h2 className="mb-3">Post a Ride</h2>
      {msg && <div className="alert alert-success">{msg}</div>}
      {err && <div className="alert alert-danger">{err}</div>}
      <form className="card p-4 shadow-sm" onSubmit={submit}>
        <div className="row g-3">
          <div className="col-md-6">
            <label className="form-label">Source</label>
            <input className="form-control" name="source" value={form.source} onChange={onChange} required />
          </div>
          <div className="col-md-6">
            <label className="form-label">Destination</label>
            <input className="form-control" name="destination" value={form.destination} onChange={onChange} required />
          </div>
          <div className="col-md-4">
            <label className="form-label">Date</label>
            <input type="date" className="form-control" name="departure_date" value={form.departure_date} onChange={onChange} required />
          </div>
          <div className="col-md-4">
            <label className="form-label">Time</label>
            <input type="time" className="form-control" name="departure_time" value={form.departure_time} onChange={onChange} required />
          </div>
          <div className="col-md-2">
            <label className="form-label">Seats</label>
            <input type="number" min="1" className="form-control" name="seats_total" value={form.seats_total} onChange={onChange} required />
          </div>
          <div className="col-md-2">
            <label className="form-label">Price (₹)</label>
            <input type="number" min="0" className="form-control" name="price" value={form.price} onChange={onChange} />
          </div>
        </div>
        <button className="btn btn-dark mt-3">Post Ride</button>
      </form>
    </div>
  );
}
