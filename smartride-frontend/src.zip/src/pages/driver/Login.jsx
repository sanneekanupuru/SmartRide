import { Link } from "react-router-dom";

export default function DriverLogin() {
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-5rem)] px-4">
      <div className="w-full max-w-md bg-white shadow-lg rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-brandBlue mb-6">Driver Login</h2>

        <form className="space-y-4">
          <input
            type="text"
            placeholder="Email or Phone Number"
            required
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-brandBlue outline-none"
          />
          <input
            type="password"
            placeholder="Password"
            required
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-brandBlue outline-none"
          />

          <button
            type="submit"
            className="w-full bg-brandBlue text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition"
          >
            Login
          </button>
        </form>

        <p className="mt-6 text-center text-sm">
          Don’t have an account?{" "}
          <Link to="/driver/register" className="text-brandBlue font-medium hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
