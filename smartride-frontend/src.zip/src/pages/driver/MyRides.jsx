import { useEffect, useState } from "react";
import api from "../../services/api";

export default function DriverMyRides(){
  const [rides, setRides] = useState([]);
  const [err, setErr] = useState("");

  useEffect(()=>{
    (async ()=>{
      try{
        const { data } = await api.get("/rides/mine");
        setRides(data || []);
      }catch(e){
        setErr(e?.response?.data?.message || "Failed to load rides");
      }
    })();
  },[]);

  return (
    <div className="container py-5">
      <h2 className="mb-3">My Rides</h2>
      {err && <div className="alert alert-danger">{err}</div>}
      <div className="table-responsive">
        <table className="table table-striped">
          <thead><tr><th>From</th><th>To</th><th>Date</th><th>Time</th><th>Seats Avail</th><th>Price</th></tr></thead>
          <tbody>
            {rides.map(r=>(
              <tr key={r.id}>
                <td>{r.source}</td>
                <td>{r.destination}</td>
                <td>{r.departure_date}</td>
                <td>{r.departure_time}</td>
                <td>{r.seats_available}</td>
                <td>{r.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
